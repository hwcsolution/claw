#!/usr/bin/env python3
"""
每日热点追踪系统 - 主程序
监控微博、知乎等平台的科技数码热点，发送QQ提醒，自动生成蹭热点文案草稿
"""

import json
import os
import time
import logging
import sys
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import re

class DailyHotspotTracker:
    def __init__(self, config_path: str = None):
        """初始化热点追踪器"""
        self.config_path = config_path or "hotspot_config.json"
        self.state_path = "hotspot_state.json"
        self.load_config()
        self.load_state()
        
        # 设置日志
        self.setup_logging()
        
    def setup_logging(self):
        """设置日志"""
        log_dir = "logs"
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(log_dir, "hotspot_monitor.log")),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
        
    def load_config(self):
        """加载配置文件"""
        default_config = {
            "tech_keywords": [
                "苹果", "华为", "小米", "OPPO", "vivo", "三星",
                "iPhone", "Android", "Windows", "Mac", "iPad",
                "AI", "人工智能", "ChatGPT", "大模型", "机器学习",
                "芯片", "半导体", "处理器", "GPU", "CPU",
                "5G", "6G", "物联网", "云计算", "区块链",
                "新能源汽车", "电动车", "自动驾驶", "特斯拉",
                "游戏", "手游", "电竞", "主机", "Steam",
                "发布", "新品", "上市", "评测", "爆料"
            ],
            "platforms": {
                "weibo": {"enabled": True, "name": "微博", "check_interval": 1800},
                "zhihu": {"enabled": True, "name": "知乎", "check_interval": 1800},
                "douyin": {"enabled": True, "name": "抖音", "check_interval": 1800},
                "bilibili": {"enabled": True, "name": "B站", "check_interval": 3600},
                "baidu": {"enabled": True, "name": "百度", "check_interval": 3600},
                "toutiao": {"enabled": True, "name": "头条", "check_interval": 3600}
            },
            "min_hot_value": 500000,
            "max_items_per_platform": 20,
            "qq_notification": False,
            "generate_draft": True,
            "check_interval": 300,
            "content_categories": {
                "short_post": True,
                "long_article": True,
                "video_script": True,
                "carousel": True
            }
        }
        
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config = json.load(f)
                self.logger.info(f"配置文件加载成功: {self.config_path}")
            else:
                self.config = default_config
                self.save_config()
                self.logger.info(f"使用默认配置，已保存到: {self.config_path}")
        except Exception as e:
            self.logger.error(f"加载配置文件失败: {e}")
            self.config = default_config
            
    def save_config(self):
        """保存配置文件"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, ensure_ascii=False, indent=2)
            self.logger.info(f"配置文件已保存: {self.config_path}")
        except Exception as e:
            self.logger.error(f"保存配置文件失败: {e}")
            
    def load_state(self):
        """加载状态文件"""
        default_state = {
            "last_check_time": None,
            "platform_checks": {},
            "processed_items": [],
            "statistics": {
                "total_checks": 0,
                "total_matches": 0,
                "total_notifications": 0,
                "total_drafts": 0,
                "platform_stats": {}
            }
        }
        
        try:
            if os.path.exists(self.state_path):
                with open(self.state_path, 'r', encoding='utf-8') as f:
                    self.state = json.load(f)
                self.logger.info(f"状态文件加载成功: {self.state_path}")
            else:
                self.state = default_state
                self.save_state()
                self.logger.info(f"使用默认状态，已保存到: {self.state_path}")
        except Exception as e:
            self.logger.error(f"加载状态文件失败: {e}")
            self.state = default_state
            
    def save_state(self):
        """保存状态文件"""
        try:
            with open(self.state_path, 'w', encoding='utf-8') as f:
                json.dump(self.state, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self.logger.error(f"保存状态文件失败: {e}")
            
    def check_platform(self, platform: str) -> List[Dict]:
        """检查平台热点（模拟数据）"""
        self.logger.info(f"检查{platform}热点...")
        
        # 模拟热点数据
        hotspots = []
        if platform == "weibo":
            hotspots = [
                {"rank": 1, "topic": "苹果WWDC新品发布会", "hot_value": 8500000, "url": "#", "category": "科技"},
                {"rank": 3, "topic": "小米14 Ultra影像评测", "hot_value": 5200000, "url": "#", "category": "手机"},
                {"rank": 5, "topic": "ChatGPT-5最新进展", "hot_value": 4800000, "url": "#", "category": "AI"}
            ]
        elif platform == "zhihu":
            hotspots = [
                {"rank": 2, "topic": "如何评价苹果Vision Pro实际体验", "hot_value": 6500000, "url": "#", "category": "VR"},
                {"rank": 4, "topic": "AI会取代哪些高薪工作", "hot_value": 5800000, "url": "#", "category": "AI"}
            ]
        elif platform == "douyin":
            hotspots = [
                {"rank": 1, "topic": "最新折叠屏手机对比评测", "hot_value": 9500000, "url": "#", "category": "手机"}
            ]
            
        # 添加平台信息
        for hotspot in hotspots:
            hotspot["platform"] = platform
            hotspot["timestamp"] = datetime.now().isoformat()
            
        return hotspots
        
    def match_keywords(self, topic: str) -> List[str]:
        """匹配关键词"""
        matched = []
        keywords = self.config.get("tech_keywords", [])
        
        for keyword in keywords:
            if keyword.lower() in topic.lower():
                matched.append(keyword)
                
        return matched
        
    def analyze_hotspot(self, hotspot: Dict) -> Dict:
        """分析热点潜力"""
        topic = hotspot.get("topic", "")
        hot_value = hotspot.get("hot_value", 0)
        rank = hotspot.get("rank", 999)
        
        # 基础分数计算
        score = 0
        
        # 热度分数
        if hot_value > 10000000:
            score += 30
        elif hot_value > 5000000:
            score += 20
        elif hot_value > 1000000:
            score += 10
            
        # 排名分数
        if rank <= 3:
            score += 25
        elif rank <= 10:
            score += 15
        elif rank <= 20:
            score += 5
            
        # 关键词匹配分数
        matched_keywords = self.match_keywords(topic)
        score += len(matched_keywords) * 5
        
        # 评估潜力等级
        if score >= 80:
            potential = "S级（必跟）"
            action = "立即创作，抢占先机"
        elif score >= 60:
            potential = "A级（优质）"
            action = "尽快创作，争取流量"
        elif score >= 40:
            potential = "B级（可选）"
            action = "选择性创作"
        else:
            potential = "C级（观察）"
            action = "保持关注，暂不创作"
            
        return {
            "score": round(score, 1),
            "potential": potential,
            "action": action,
            "matched_keywords": matched_keywords
        }
        
    def generate_content(self, hotspot: Dict, analysis: Dict) -> Dict:
        """生成内容建议"""
        topic = hotspot.get("topic", "")
        matched_keywords = analysis.get("matched_keywords", [])
        
        suggestions = {
            "short_post": [
                f"🔥【{topic}】最新进展！\n💡 核心看点：\n1. \n2. \n3. \n\n🎯 对我们有什么启发？\n\n#{' #'.join(matched_keywords[:3]) if matched_keywords else '科技'}",
                f"📱 关于{topic}，我的看法：\n\n👍 优点：\n1. \n2. \n\n👎 不足：\n1. \n2. \n\n🤔 你会选择吗？\n\n#{' #'.join(matched_keywords[:3]) if matched_keywords else '数码'}"
            ],
            "long_article": [
                f"# {topic}：深度分析与展望\n\n## 一、背景介绍\n\n## 二、核心看点\n1. \n2. \n3. \n\n## 三、市场影响\n\n## 四、未来趋势\n\n## 五、个人观点\n\n关键词：{', '.join(matched_keywords)}"
            ],
            "video_script": [
                f"【视频脚本】{topic}\n\n📌 开头（0-15秒）：\n- 热点引入：{topic}\n- 数据展示\n- 提出问题\n\n📌 主体（15-60秒）：\n- 核心分析\n- 对比说明\n- 用户价值\n\n📌 结尾（60-90秒）：\n- 总结观点\n- 互动提问\n- 引导关注"
            ],
            "carousel": [
                f"【轮播图】{topic}\n\n第1页：封面\n- 标题：{topic}\n- 副标题：深度解析\n\n第2页：背景介绍\n\n第3页：核心分析\n\n第4页：影响评估\n\n第5页：行动建议\n\n第6页：互动引导"
            ]
        }
        
        return suggestions
        
    def save_draft(self, hotspot: Dict, analysis: Dict, suggestions: Dict):
        """保存内容草稿"""
        try:
            content_dir = "hotspot_content"
            os.makedirs(content_dir, exist_ok=True)
            
            # 生成文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            platform = hotspot.get("platform", "unknown")
            topic_slug = re.sub(r'[^\w\-_]', '_', hotspot.get("topic", "unknown")[:50])
            filename = f"{timestamp}_{platform}_{topic_slug}.md"
            filepath = os.path.join(content_dir, filename)
            
            # 写入文件
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(f"# 热点内容策划：{hotspot.get('topic')}\n\n")
                f.write(f"**检测时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"**平台**: {hotspot.get('platform')}\n")
                f.write(f"**热度**: {hotspot.get('hot_value')}\n")
                f.write(f"**排名**: #{hotspot.get('rank')}\n")
                f.write(f"**潜力评分**: {analysis.get('score', 0)} ({analysis.get('potential', '未知')})\n")
                f.write(f"**匹配关键词**: {', '.join(analysis.get('matched_keywords', []))}\n\n")
                
                f.write(f"## 🎯 行动建议\n\n")
                f.write(f"{analysis.get('action', '保持关注')}\n\n")
                
                f.write(f"## 📝 内容草稿\n\n")
                
                categories = self.config.get("content_categories", {})
                if categories.get("short_post", True):
                    f.write(f"### 短内容（微博/推特）\n\n")
                    for i, template in enumerate(suggestions.get("short_post", [])[:2], 1):
                        f.write(f"**版本{i}**:\n```\n{template}\n```\n\n")
                
                if categories.get("long_article", True):
                    f.write(f"### 长文章（知乎/公众号）\n\n")
                    for i, template in enumerate(suggestions.get("long_article", [])[:2], 1):
                        f.write(f"**版本{i}**:\n```\n{template}\n```\n\n")
                
                if categories.get("video_script", True):
                    f.write(f"### 视频脚本\n\n")
                    for i, template in enumerate(suggestions.get("video_script", [])[:2], 1):
                        f.write(f"**版本{i}**:\n```\n{template}\n```\n\n")
                
                if categories.get("carousel", True):
                    f.write(f"### 轮播图内容\n\n")
                    for i, template in enumerate(suggestions.get("carousel", [])[:2], 1):
                        f.write(f"**版本{i}**:\n```\n{template}\n```\n\n")
                
                f.write(f"---\n")
                f.write(f"*自动生成于 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*\n")
                
            self.logger.info(f"内容草稿已保存: {filepath}")
            self.state["statistics"]["total_drafts"] += 1
            
        except Exception as e:
            self.logger.error(f"保存内容草稿失败: {e}")
            
    def send_notification(self, hotspot: Dict, analysis: Dict):
        """发送通知"""
        if not self.config.get("qq_notification", False):
            return
            
        self.logger.info(f"发现热点: {hotspot.get('topic')} (平台: {hotspot.get('platform')}, 潜力: {analysis.get('potential')})")
        self.state["statistics"]["total_notifications"] += 1
        
    def check_all_platforms(self) -> int:
        """检查所有平台"""
        self.logger.info("开始检查所有平台热点...")
        self.state["statistics"]["total_checks"] += 1
        
        matches = 0
        
        for platform_id, platform_config in self.config.get("platforms", {}).items():
            if not platform_config.get("enabled", False):
                continue
                
            self.logger.info(f"检查 {platform_config.get('name', platform_id)}...")
            hotspots = self.check_platform(platform_id)
            
            for hotspot in hotspots:
                # 分析热点潜力
                analysis = self.analyze_hotspot(hotspot)
                
                # 检查是否匹配关键词
                if not analysis.get("matched_keywords"):
                    continue
                    
                # 检查热度阈值
                min_hot = self.config.get("min_hot_value", 500000)
                if hotspot.get("hot_value", 0) < min_hot:
                    continue
                    
                # 检查是否已处理
                item_id = f"{hotspot.get('platform')}_{hotspot.get('rank')}_{hotspot.get('topic')}"
                if item_id in self.state.get("processed_items", []):
                    continue
                    
                self.logger.info(f"发现匹配热点: {hotspot.get('topic')} (平台: {hotspot.get('platform')}, 潜力: {analysis.get('potential')})")
                
                # 生成内容建议
                suggestions = self.generate_content(hotspot, analysis)
                
                # 发送通知
                self.send_notification(hotspot, analysis)
                
                # 保存内容草稿
                if self.config.get("generate_draft", True):
                    self.save_draft(hotspot, analysis, suggestions)
                
                # 更新平台统计
                platform_stats = self.state["statistics"].setdefault("platform_stats", {})
                platform_stats[hotspot.get("platform")] = platform_stats.get(hotspot.get("platform"), 0) + 1
                
                # 标记为已处理
                self.state.setdefault("processed_items", []).append(item_id)
                matches += 1
            
            # 更新平台检查时间
            self.state.setdefault("platform_checks", {})[platform_id] = datetime.now().isoformat()
            
        # 更新统计
        self.state["statistics"]["total_matches"] += matches
        self.state["last_check_time"] = datetime.now().isoformat()
        self.save_state()
        
        self.logger.info(f"平台检查完成，匹配到 {matches} 个热点")
        return matches
        
    def run_once(self) -> int:
        """运行一次检查"""
        try:
            self.logger.info("开始热点检查...")
            matches = self.check_all_platforms()
            self.logger.info(f"热点检查完成，匹配到 {matches} 个热点")
            return matches
        except Exception as e:
            self.logger.error(f"热点检查运行失败: {e}")
            return 0
            
    def run_continuously(self):
        """持续运行监控"""
        check_interval = self.config.get("check_interval", 300)
        
        self.logger.info(f"热点监控系统启动，检查间隔: {check_interval}秒")
        self.logger.info(f"监控平台: {[p['name'] for p in self.config.get('platforms', {}).values() if p.get('enabled')]}")
        
        while True:
            try:
                self.run_once()
                
                # 计算下次检查时间
                next_check = datetime.now() + timedelta(seconds=check_interval)
                self.logger.info(f"等待 {check_interval} 秒后进行下一次检查... (下次检查: {next_check.strftime('%H:%M:%S')})")
                time.sleep(check_interval)
                
            except KeyboardInterrupt:
                self.logger.info("收到中断信号，停止监控")
                break
            except Exception as e:
                self.logger.error(f"监控循环异常: {e}")
                time.sleep(60)
                
def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="每日热点追踪系统")
    parser.add_argument("--once", action="store_true", help="运行一次检查")
    parser.add_argument("--daemon", action="store_true", help="后台持续运行")
    parser.add_argument("--config", help="配置文件路径")
    parser.add_argument("--test", action="store_true", help="测试模式")
    parser.add_argument("--init-config", action="store_true", help="初始化配置文件")
    
    args = parser.parse_args()
    
    tracker = DailyHotspotTracker(args.config)
    
    if args.init_config:
        print("配置文件已初始化")
        print(f"配置文件位置: {tracker.config_path}")
        print(f"状态文件位置: {tracker.state_path}")
        print("请编辑配置文件以启用QQ通知等功能")
        
    elif args.test:
        print("测试热点追踪系统...")
        print(f"监控平台: {[p['name'] for p in tracker.config.get('platforms', {}).values() if p.get('enabled')]}")
        print(f"关键词数量: {len(tracker.config.get('tech_keywords', []))}")
        
        # 测试热点分析
        test_hotspot = {
            "platform": "weibo",
            "rank": 1,
            "topic": "苹果WWDC 2024新品发布会",
            "hot_value": 8500000,
            "url": "#",
            "category": "科技"
        }
        
        analysis = tracker.analyze_hotspot(test_hotspot)
        print(f"\n测试热点分析:")
        print(f"话题: {test_hotspot['topic']}")
        print(f"潜力评分: {analysis['score']}")
        print(f"潜力等级: {analysis['potential']}")
        print(f"匹配关键词: {analysis['matched_keywords']}")
        print(f"行动建议: {analysis['action']}")
        
        # 测试内容生成
        suggestions = tracker.generate_content(test_hotspot, analysis)
        print(f"\n内容建议生成成功:")
        print(f"- 短内容模板: {len(suggestions.get('short_post', []))}个")
        print(f"- 长文章模板: {len(suggestions.get('long_article', []))}个")
        print(f"- 视频脚本: {len(suggestions.get('video_script', []))}个")
        print(f"- 轮播图: {len(suggestions.get('carousel', []))}个")
        
        # 测试文件保存
        tracker.save_draft(test_hotspot, analysis, suggestions)
        print(f"\n内容草稿已保存到 hotspot_content/ 目录")
        
    elif args.daemon:
        tracker.run_continuously()
    else:
        matches = tracker.run_once()
        print(f"检查完成，匹配到 {matches} 个热点")
        
if __name__ == "__main__":
    main()