#!/bin/bash
# 每日热点追踪系统 - 启动脚本

echo "启动每日热点追踪系统..."

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 创建必要目录
echo "创建必要目录..."
mkdir -p logs
mkdir -p hotspot_content
mkdir -p trend_reports
mkdir -p comprehensive_reports

# 检查Python依赖
echo "检查Python依赖..."
python3 -c "import requests" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "安装requests库..."
    pip3 install requests
fi

# 检查配置文件
if [ ! -f "hotspot_config.json" ]; then
    echo "配置文件不存在，正在初始化..."
    python3 daily_hotspot_tracker.py --init-config
fi

# 启动监控
echo "启动热点监控..."
python3 daily_hotspot_tracker.py --daemon &

# 获取进程ID
PID=$!
echo "监控进程已启动，PID: $PID"

# 保存进程ID到文件
echo $PID > hotspot_monitor.pid

echo ""
echo "========================================"
echo "热点捕手已启动！"
echo "========================================"
echo ""
echo "查看日志: tail -f logs/hotspot_monitor.log"
echo "停止监控: bash stop_monitor.sh"
echo "测试系统: bash test_monitor.sh"
echo ""
echo "配置文件: hotspot_config.json"
echo "状态文件: hotspot_state.json"
echo "内容草稿: hotspot_content/"
echo "趋势报告: trend_reports/"
echo "综合报告: comprehensive_reports/"
echo ""
echo "========================================"
echo "系统正在后台运行中..."
echo "按 Ctrl+C 不会停止后台进程"
echo "使用 stop_monitor.sh 停止监控"
echo "========================================"