#!/usr/bin/env python3
"""
设置定时任务
"""

import os
import sys
import subprocess
from datetime import datetime

def setup_cron():
    """设置cron定时任务"""
    print("设置每日热点追踪系统定时任务...")
    
    # 获取当前工作目录
    current_dir = os.path.dirname(os.path.abspath(__file__))
    python_path = sys.executable
    script_path = os.path.join(current_dir, "daily_hotspot_tracker.py")
    
    # cron表达式：每5分钟运行一次
    cron_expression = "*/5 * * * *"
    
    # 构建cron命令
    cron_command = f'cd "{current_dir}" && {python_path} "{script_path}" --once >> "{current_dir}/logs/cron.log" 2>&1'
    
    # 显示cron配置
    print("\n请将以下行添加到crontab中：")
    print("=" * 80)
    print(f"{cron_expression} {cron_command}")
    print("=" * 80)
    
    # 生成安装脚本
    install_script = f"""#!/bin/bash
# 每日热点追踪系统 - 定时任务安装脚本

echo "安装每日热点追踪系统定时任务..."

# 创建日志目录
mkdir -p "{current_dir}/logs"

# 添加cron任务
(crontab -l 2>/dev/null; echo "{cron_expression} {cron_command}") | crontab -

echo "定时任务安装完成！"
echo "检查cron任务：crontab -l"
echo "查看日志：tail -f {current_dir}/logs/cron.log"
"""
    
    # 保存安装脚本
    install_script_path = os.path.join(current_dir, "install_cron.sh")
    with open(install_script_path, 'w', encoding='utf-8') as f:
        f.write(install_script)
    
    # 设置执行权限
    os.chmod(install_script_path, 0o755)
    
    print(f"\n已生成安装脚本：{install_script_path}")
    print("运行以下命令安装定时任务：")
    print(f"bash {install_script_path}")
    
    # 生成卸载脚本
    uninstall_script = f"""#!/bin/bash
# 每日热点追踪系统 - 定时任务卸载脚本

echo "卸载每日热点追踪系统定时任务..."

# 从crontab中移除相关任务
crontab -l 2>/dev/null | grep -v "daily_hotspot_tracker.py" | crontab -

echo "定时任务已卸载！"
echo "检查cron任务：crontab -l"
"""
    
    # 保存卸载脚本
    uninstall_script_path = os.path.join(current_dir, "uninstall_cron.sh")
    with open(uninstall_script_path, 'w', encoding='utf-8') as f:
        f.write(uninstall_script)
    
    # 设置执行权限
    os.chmod(uninstall_script_path, 0o755)
    
    print(f"\n已生成卸载脚本：{uninstall_script_path}")
    print("运行以下命令卸载定时任务：")
    print(f"bash {uninstall_script_path}")
    
    # 生成手动启动脚本
    start_script = f"""#!/bin/bash
# 每日热点追踪系统 - 手动启动脚本

echo "启动每日热点追踪系统..."

# 创建必要目录
mkdir -p "{current_dir}/logs"
mkdir -p "{current_dir}/hotspot_content"
mkdir -p "{current_dir}/trend_reports"
mkdir -p "{current_dir}/comprehensive_reports"

# 启动监控
cd "{current_dir}"
{python_path} "{script_path}" --daemon

echo "系统已启动！"
echo "查看日志：tail -f {current_dir}/logs/hotspot_monitor.log"
"""
    
    # 保存启动脚本
    start_script_path = os.path.join(current_dir, "start_monitor.sh")
    with open(start_script_path, 'w', encoding='utf-8') as f:
        f.write(start_script)
    
    # 设置执行权限
    os.chmod(start_script_path, 0o755)
    
    print(f"\n已生成启动脚本：{start_script_path}")
    print("运行以下命令手动启动监控：")
    print(f"bash {start_script_path}")
    
    # 生成停止脚本
    stop_script = f"""#!/bin/bash
# 每日热点追踪系统 - 停止脚本

echo "停止每日热点追踪系统..."

# 查找并停止进程
pkill -f "daily_hotspot_tracker.py" || true

echo "系统已停止！"
"""
    
    # 保存停止脚本
    stop_script_path = os.path.join(current_dir, "stop_monitor.sh")
    with open(stop_script_path, 'w', encoding='utf-8') as f:
        f.write(stop_script)
    
    # 设置执行权限
    os.chmod(stop_script_path, 0o755)
    
    print(f"\n已生成停止脚本：{stop_script_path}")
    print("运行以下命令停止监控：")
    print(f"bash {stop_script_path}")
    
    # 生成测试脚本
    test_script = f"""#!/bin/bash
# 每日热点追踪系统 - 测试脚本

echo "测试每日热点追踪系统..."

# 创建必要目录
mkdir -p "{current_dir}/logs"
mkdir -p "{current_dir}/hotspot_content"
mkdir -p "{current_dir}/trend_reports"
mkdir -p "{current_dir}/comprehensive_reports"

# 运行测试
cd "{current_dir}"
{python_path} "{script_path}" --test

echo "测试完成！"
echo "查看生成的内容草稿：ls {current_dir}/hotspot_content/"
"""
    
    # 保存测试脚本
    test_script_path = os.path.join(current_dir, "test_monitor.sh")
    with open(test_script_path, 'w', encoding='utf-8') as f:
        f.write(test_script)
    
    # 设置执行权限
    os.chmod(test_script_path, 0o755)
    
    print(f"\n已生成测试脚本：{test_script_path}")
    print("运行以下命令测试系统：")
    print(f"bash {test_script_path}")
    
    print("\n" + "=" * 80)
    print("安装完成！")
    print("=" * 80)
    print("\n使用说明：")
    print("1. 首次使用：bash install_cron.sh （安装定时任务）")
    print("2. 手动测试：bash test_monitor.sh （测试系统功能）")
    print("3. 手动启动：bash start_monitor.sh （后台运行）")
    print("4. 停止监控：bash stop_monitor.sh （停止后台进程）")
    print("5. 卸载任务：bash uninstall_cron.sh （移除定时任务）")
    print("\n配置文件：hotspot_config.json")
    print("状态文件：hotspot_state.json")
    print("日志目录：logs/")
    print("内容草稿：hotspot_content/")
    print("趋势报告：trend_reports/")
    print("综合报告：comprehensive_reports/")

if __name__ == "__main__":
    setup_cron()