---
name: daily-hotspot-tracker
description: 每日热点追踪系统 - 监控微博、知乎等平台的科技数码热点，发送QQ提醒，自动生成蹭热点文案草稿
---

# 每日热点追踪系统

一个全自动的科技数码热点监控系统，支持多平台热点发现、智能分析、内容生成和实时提醒。

## 功能特性

### 🎯 核心功能
- **多平台监控**: 微博、知乎、百度热搜、抖音、B站、今日头条等8个平台
- **科技数码专注**: 200+科技数码关键词库精准匹配
- **智能分析**: S/A/B/C四级潜力评分系统
- **内容生成**: 自动生成4种内容形式（短内容、长文章、视频脚本、轮播图）
- **实时提醒**: QQ消息即时推送热点信息
- **数据分析**: 趋势报告、平台统计、关键词热度分析

### 📊 智能评分维度
1. **热度分数**: 基于平台热度值
2. **排名分数**: 基于热点排名
3. **平台权重**: 不同平台权重不同
4. **关键词匹配**: 匹配关键词数量
5. **时效性**: 热点新鲜度

### 📝 内容形式
1. **短内容**: 适合微博/推特（150字内）
2. **长文章**: 适合知乎/公众号（2000字左右）
3. **视频脚本**: 适合抖音/B站（60-90秒）
4. **轮播图**: 适合小红书/Instagram

## 安装依赖

```bash
pip install requests
```

## 快速开始

### 1. 初始化配置
```bash
# 创建配置文件
python daily_hotspot_tracker.py --init-config

# 测试系统
python daily_hotspot_tracker.py --test
```

### 2. 配置QQ通知
编辑 `hotspot_config.json`，配置QQ通知方式：
- Server酱
- PushPlus
- CoolQ
- Mirai

### 3. 启动监控
```bash
# 单次运行
python daily_hotspot_tracker.py --once

# 后台持续运行
python daily_hotspot_tracker.py --daemon

# 设置定时任务（每5分钟）
python setup_cron.py
```

## 配置文件说明

### 主要配置项
```json
{
  "tech_keywords": ["苹果", "华为", "AI", "芯片", ...],
  "platforms": {
    "weibo": {"enabled": true, "check_interval": 1800},
    "zhihu": {"enabled": true, "check_interval": 1800}
  },
  "min_hot_value": 500000,
  "qq_notification": true,
  "generate_draft": true
}
```

### 平台配置
- **weibo**: 微博热搜（30分钟检查）
- **zhihu**: 知乎热榜（30分钟检查）
- **douyin**: 抖音热榜（30分钟检查）
- **bilibili**: B站热榜（1小时检查）
- **baidu**: 百度热搜（1小时检查）
- **toutiao**: 今日头条（1小时检查）
- **reddit**: Reddit热门（2小时检查，默认禁用）
- **twitter**: Twitter趋势（2小时检查，默认禁用）

## 使用方法

### 基本监控
```bash
# 启动监控服务
python daily_hotspot_tracker.py --daemon

# 查看日志
tail -f hotspot_monitor.log
```

### 生成报告
```bash
# 生成趋势报告
python daily_hotspot_tracker.py --report

# 查看内容草稿
ls hotspot_content/
ls trend_reports/
```

### 测试模式
```bash
# 测试关键词匹配
python daily_hotspot_tracker.py --test

# 测试特定平台
python daily_hotspot_tracker.py --platform weibo --test
```

## 文件结构

```
daily-hotspot-tracker/
├── daily_hotspot_tracker.py      # 主程序
├── hotspot_config.json           # 配置文件
├── hotspot_state.json           # 状态文件
├── setup_cron.py                # 定时任务设置
├── start_monitor.sh             # 启动脚本
├── stop_monitor.sh              # 停止脚本
├── test_monitor.sh              # 测试脚本
├── hotspot_content/             # 内容草稿目录
├── trend_reports/               # 趋势报告目录
└── logs/                        # 日志目录
```

## 输出文件

### 内容草稿
- 位置: `hotspot_content/`
- 格式: `YYYYMMDD_HHMMSS_平台_话题.md`
- 内容: 完整的创作建议和模板

### 趋势报告
- 位置: `trend_reports/`
- 格式: `enhanced_trends_YYYYMMDD_HHMMSS.md`
- 内容: 热点分析、平台统计、创作建议

### 综合报告
- 位置: `comprehensive_reports/`
- 格式: `comprehensive_report_YYYYMMDD.md`
- 内容: 日报、趋势预测、性能指标

## 集成技能

本技能可与以下技能配合使用：
- **multi-search-engine**: 多搜索引擎，用于热点深度搜索
- **wechat-article-extractor-skill**: 微信公众号文章解析
- **social-trend-monitor**: 社交媒体趋势监控
- **weibo-hot-search**: 微博热搜查询

## 自定义配置

### 修改关键词库
编辑 `hotspot_config.json` 中的 `tech_keywords` 数组，添加或删除关键词。

### 调整平台设置
修改 `platforms` 配置，启用/禁用平台，调整检查频率。

### 自定义通知模板
修改 `notification_template` 字段，自定义QQ消息格式。

### 调整内容生成
修改 `content_categories` 配置，启用/禁用不同类型的内容生成。

## 故障排除

### 常见问题
1. **QQ通知未发送**: 检查配置文件中的QQ通知设置
2. **热点未匹配**: 检查关键词库和热度阈值
3. **日志文件过大**: 定期清理 `logs/` 目录
4. **内存占用过高**: 调整 `max_items_per_platform` 参数

### 日志查看
```bash
# 实时查看日志
tail -f logs/hotspot_monitor.log

# 查看错误日志
grep ERROR logs/hotspot_monitor.log

# 查看匹配的热点
grep "发现匹配热点" logs/hotspot_monitor.log
```

## 性能优化

### 内存优化
- 设置 `max_items_per_platform` 限制每个平台获取的热点数量
- 定期清理 `hotspot_state.json` 中的已处理记录
- 使用增量检查，避免重复处理

### 网络优化
- 设置合理的 `check_interval` 避免频繁请求
- 使用缓存机制减少重复搜索
- 支持代理设置（如需访问国外平台）

### 存储优化
- 自动清理7天前的报告和草稿
- 压缩历史数据
- 支持数据库存储（可选）

## 扩展开发

### 添加新平台
1. 在 `platforms` 配置中添加新平台
2. 实现 `_check_xxx_hotspots()` 方法
3. 更新平台权重和检查频率

### 添加新内容形式
1. 在 `content_categories` 中添加新类型
2. 实现对应的内容生成方法
3. 更新内容建议模板

### 集成真实API
1. 替换模拟数据函数为真实API调用
2. 添加API认证和错误处理
3. 实现请求频率限制

## 安全注意事项

### 配置文件安全
- 不要将包含API密钥的配置文件提交到版本控制
- 使用环境变量存储敏感信息
- 定期更新API密钥

### 数据安全
- 热点数据仅用于内容创作参考
- 遵守各平台的使用条款
- 不存储用户隐私数据

### 系统安全
- 设置合理的请求频率
- 实现错误重试机制
- 监控系统资源使用

## 许可证

MIT License

## 支持与反馈

如有问题或建议，请提交Issue或联系开发者。

---

**版本**: 2.0.0  
**最后更新**: 2026-05-12  
**作者**: Daily Hotspot Tracker Team