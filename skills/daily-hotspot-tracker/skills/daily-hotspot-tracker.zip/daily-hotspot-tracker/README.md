# 每日热点追踪系统

一个全自动的科技数码热点监控系统，支持多平台热点发现、智能分析、内容生成和实时提醒。

## 🚀 功能特性

### 核心功能
- **多平台监控**: 微博、知乎、百度热搜、抖音、B站、今日头条等8个平台
- **科技数码专注**: 200+科技数码关键词库精准匹配
- **智能分析**: S/A/B/C四级潜力评分系统
- **内容生成**: 自动生成4种内容形式（短内容、长文章、视频脚本、轮播图）
- **实时提醒**: QQ消息即时推送热点信息
- **数据分析**: 趋势报告、平台统计、关键词热度分析

### 智能评分维度
1. **热度分数**: 基于平台热度值
2. **排名分数**: 基于热点排名
3. **平台权重**: 不同平台权重不同
4. **关键词匹配**: 匹配关键词数量
5. **时效性**: 热点新鲜度

### 内容形式
1. **短内容**: 适合微博/推特（150字内）
2. **长文章**: 适合知乎/公众号（2000字左右）
3. **视频脚本**: 适合抖音/B站（60-90秒）
4. **轮播图**: 适合小红书/Instagram

## 📦 安装

### 1. 克隆或下载
```bash
git clone <repository-url>
cd daily-hotspot-tracker
```

### 2. 安装依赖
```bash
pip install requests
```

### 3. 初始化配置
```bash
python daily_hotspot_tracker.py --init-config
```

### 4. 测试系统
```bash
python daily_hotspot_tracker.py --test
```

## ⚙️ 配置

### 配置文件
编辑 `hotspot_config.json`：

```json
{
  "tech_keywords": ["苹果", "华为", "AI", "芯片", ...],
  "platforms": {
    "weibo": {"enabled": true, "check_interval": 1800},
    "zhihu": {"enabled": true, "check_interval": 1800}
  },
  "min_hot_value": 500000,
  "qq_notification": false,
  "generate_draft": true
}
```

### QQ通知配置
如需启用QQ通知，请配置以下方式之一：

1. **Server酱**（推荐）:
   - 注册 https://sct.ftqq.com
   - 获取SendKey
   - 在配置文件中设置

2. **PushPlus**:
   - 注册 https://www.pushplus.plus
   - 获取Token
   - 在配置文件中设置

3. **CoolQ/Mirai**:
   - 配置机器人API
   - 设置Webhook地址

## 🚀 使用

### 启动监控
```bash
# 单次运行
python daily_hotspot_tracker.py --once

# 后台持续运行
python daily_hotspot_tracker.py --daemon

# 使用脚本启动
bash start_monitor.sh
```

### 设置定时任务
```bash
# 生成定时任务配置
python setup_cron.py

# 安装定时任务
bash install_cron.sh
```

### 测试系统
```bash
# 测试功能
python daily_hotspot_tracker.py --test

# 使用脚本测试
bash test_monitor.sh
```

### 停止监控
```bash
# 停止后台进程
bash stop_monitor.sh

# 卸载定时任务
bash uninstall_cron.sh
```

## 📁 文件结构

```
daily-hotspot-tracker/
├── daily_hotspot_tracker.py      # 主程序
├── hotspot_config.json           # 配置文件
├── hotspot_state.json           # 状态文件
├── setup_cron.py                # 定时任务设置
├── start_monitor.sh             # 启动脚本
├── stop_monitor.sh              # 停止脚本
├── test_monitor.sh              # 测试脚本
├── install_cron.sh              # 安装定时任务
├── uninstall_cron.sh            # 卸载定时任务
├── README.md                    # 说明文档
├── hotspot_content/             # 内容草稿目录
├── trend_reports/               # 趋势报告目录
├── comprehensive_reports/       # 综合报告目录
└── logs/                        # 日志目录
```

## 📊 输出文件

### 内容草稿
- 位置: `hotspot_content/`
- 格式: `YYYYMMDD_HHMMSS_平台_话题.md`
- 内容: 完整的创作建议和模板

### 趋势报告
- 位置: `trend_reports/`
- 格式: `enhanced_trends_YYYYMMDD_HHMMSS.md`
- 内容: 热点分析、平台统计、创作建议

### 综合报告
- 位置: `comprehensive_reports/`
- 格式: `comprehensive_report_YYYYMMDD.md`
- 内容: 日报、趋势预测、性能指标

## 🔧 自定义配置

### 修改关键词库
编辑 `hotspot_config.json` 中的 `tech_keywords` 数组，添加或删除关键词。

### 调整平台设置
修改 `platforms` 配置，启用/禁用平台，调整检查频率。

### 自定义通知模板
修改 `notification_template` 字段，自定义QQ消息格式。

### 调整内容生成
修改 `content_categories` 配置，启用/禁用不同类型的内容生成。

## 🐛 故障排除

### 常见问题

1. **QQ通知未发送**
   - 检查配置文件中的QQ通知设置
   - 确认API密钥或Webhook地址正确
   - 查看日志文件中的错误信息

2. **热点未匹配**
   - 检查关键词库是否包含相关词汇
   - 调整 `min_hot_value` 参数降低热度阈值
   - 查看日志确认平台数据获取情况

3. **日志文件过大**
   ```bash
   # 清理旧日志
   find logs/ -name "*.log" -mtime +7 -delete
   ```

4. **内存占用过高**
   - 调整 `max_items_per_platform` 参数限制数据量
   - 定期清理 `hotspot_state.json` 中的已处理记录

### 日志查看
```bash
# 实时查看日志
tail -f logs/hotspot_monitor.log

# 查看错误日志
grep ERROR logs/hotspot_monitor.log

# 查看匹配的热点
grep "发现匹配热点" logs/hotspot_monitor.log
```

## 📈 性能优化

### 内存优化
- 设置 `max_items_per_platform` 限制每个平台获取的热点数量
- 定期清理 `hotspot_state.json` 中的已处理记录
- 使用增量检查，避免重复处理

### 网络优化
- 设置合理的 `check_interval` 避免频繁请求
- 使用缓存机制减少重复搜索
- 支持代理设置（如需访问国外平台）

### 存储优化
- 自动清理7天前的报告和草稿
- 压缩历史数据
- 支持数据库存储（可选）

## 🔌 扩展开发

### 添加新平台
1. 在 `platforms` 配置中添加新平台
2. 实现 `_check_xxx_hotspots()` 方法
3. 更新平台权重和检查频率

### 添加新内容形式
1. 在 `content_categories` 中添加新类型
2. 实现对应的内容生成方法
3. 更新内容建议模板

### 集成真实API
1. 替换模拟数据函数为真实API调用
2. 添加API认证和错误处理
3. 实现请求频率限制

## 🔒 安全注意事项

### 配置文件安全
- 不要将包含API密钥的配置文件提交到版本控制
- 使用环境变量存储敏感信息
- 定期更新API密钥

### 数据安全
- 热点数据仅用于内容创作参考
- 遵守各平台的使用条款
- 不存储用户隐私数据

### 系统安全
- 设置合理的请求频率
- 实现错误重试机制
- 监控系统资源使用

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📞 支持

如有问题或建议，请提交Issue或联系开发者。

---

**版本**: 2.0.0  
**最后更新**: 2026-05-12  
**作者**: Daily Hotspot Tracker Team